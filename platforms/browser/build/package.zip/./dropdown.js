function dropdown() {
    document.getElementById("dropdownList").classList.toggle("show");//http://www.w3schools.com/howto/howto_js_dropdown.asp
}
